package cinemabooking.config;
/**
 *
 * @author charlie_r_mills
 */
public class Platform {
}
